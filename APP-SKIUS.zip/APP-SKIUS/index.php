<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>APP SKIU</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->

        <!-- App css -->
        <link href="dist/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="dist/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="dist/assets/css/app.min.css" rel="stylesheet" type="text/css" />

    </head>

    <body class="authentication-bg bg-dafault">

            <div class="account-pages mt-5 pt-5 mb-5">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-6 col-xl-5">
                            <div class="card bg-pattern">
                                <div class="card-body p-4">
                                    <div class="text-center w-75 m-auto">
                                        <H3 class="text-uppercase text-center font-bold mt-4">APP SKIU</H3>
                                    </div>
                                    <?php
                                      if(isset($_GET['notif'])){
                                        if($_GET['notif']=="gagal"){
                                          echo "
                                          <div class='alert alert-danger alert-dismissible' style='text-align:justify'>
                                          <a href='index.php' class='close' style='text-decoration:none'>&times;</a>
                                          <h4><i class='icon fa fa-ban'></i> Gagal!</h4>
                                            Proses Login gagal, Username atau password yang anda masukkan tidak terdaftar.
                                          </div>";
                                        }
                                      }else{
                                          echo"<p class='login-box-msg' style='text-align: center;'>Slahkan login disini</p>";
                                      }
                                    ?>
                                    <form action="proses_login.php" method="post">
                                        <div class="form-group mb-3">
                                            <label for="username">Username</label>
                                            <input class="form-control" type="text" id="username" name="Username" required="required" placeholder="Enter your username">
                                        </div>
    
                                        <div class="form-group mb-3">
                                            <label for="password">Password</label>
                                            <input class="form-control" name="Password" type="password" required="required" id="password" placeholder="Enter your password">
                                        </div>
    
                                        <div class="form-group mb-0 text-center">
                                            <button class="btn btn-gradient btn-block" type="submit" name="masuk"> Log In </button>
                                        </div>
                                    </form>
                                </div> <!-- end card-body -->
                            </div>
                            <!-- end card -->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- end container -->
            </div>
            <!-- end page -->


        <!-- Vendor js -->
        <script src="dist/assets/js/vendor.min.js"></script>
        <!-- App js -->
        <script src="dist/assets/js/app.min.js"></script>
        
    </body>
</html>