<?php 
include 'koneksi.php';
$id =$_GET['id'];

$nama =$_POST['nama'];
$jenis_usaha =$_POST['jenis_usaha'];
$syrat_pemohon =$_POST['syrat_pemohon'];
$skala_usaha =$_POST['skala_usaha'];
$lok_usaha =$_POST['lok_usaha'];

$edit_data =mysqli_query($konek, "UPDATE `permohonan_skiu` SET nama='$nama', jenis_usaha='$jenis_usaha', syrat_pemohon='$syrat_pemohon', skala_usaha='$skala_usaha', lok_usaha='$lok_usaha'  WHERE id_perskiu='$id'");
header("location:dashboard_admin.php?p=permohonan_skiu&notif=sukses_edit");


 ?>