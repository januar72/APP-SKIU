<?php 
session_start();
unset($_SESSION['masukone']);
 echo "<script>document.location.href='index.php'</script>\n";
 ?>