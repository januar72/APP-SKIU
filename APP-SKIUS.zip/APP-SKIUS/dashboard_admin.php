<?php 
session_start();
include 'koneksi.php';
if (!isset($_SESSION['masuk'])) {
    header("location:index.php");
    exit();
}
$campil=mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_user WHERE username='$_SESSION[masuk]'"));
 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>APP SKIU</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->

        <!-- third party css -->
        <link href="dist/assets/libs/datatables/dataTables.bootstrap4.css" rel="stylesheet" type="text/css"/>
        <link href="dist/assets/libs/datatables/buttons.bootstrap4.css" rel="stylesheet" type="text/css"/>
        <link href="dist/assets/libs/datatables/responsive.bootstrap4.css" rel="stylesheet" type="text/css"/>

        <!-- App css -->
        <link href="dist/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="dist/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="dist/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">
            <!-- Topbar Start -->
            <div class="navbar-custom">
                <ul class="list-unstyled topnav-menu float-right mb-0">

                    <li class="dropdown notification-list">
                        <a class="nav-link nav-user mr-0 waves-effect waves-light" onclick="alert('yakin ingin keluar...?')" href="logout_admin.php" role="button" aria-haspopup="false" aria-expanded="false">
                            <span class="ml-1"><i class="fe-log-out"></i> <?php echo $campil['jabatan']; ?></span>
                        </a>
                    </li>

                    <li class="dropdown notification-list">
                        <a href="javascript:void(0);" class="nav-link right-bar-toggle waves-effect waves-light">
                            <i class="fe-bell"></i>
                        </a>
                    </li>
                </ul>

                <!-- LOGO -->
                <div class="logo-box">
                    <a class="logo text-center">
                        <span class="logo-lg">
                            <h3 style="color: white;">APP SKIU</h3>
                            <!-- <span class="logo-lg-text-light">UBold</span> -->
                        </span>
                        <span class="logo-sm">
                            <!-- <span class="logo-sm-text-dark">U</span> -->
                            <img src="dist/assets/images/logo-sm.png" alt="" height="28">
                        </span>
                    </a>
                </div>
                <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                    <li>
                        <button class="button-menu-mobile waves-effect waves-light">
                            <i class="fe-menu"></i>
                        </button>
                    </li>
                    <li class="d-none d-sm-block">
                        <form class="app-search">
                            <div class="app-search-box">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <div class="input-group-append">
                                        <button class="btn" type="submit">
                                            <i class="fe-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </li>
                </ul>
            </div>
            <!-- end Topbar -->

            <!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu">

                <div class="slimscroll-menu">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul class="metismenu" id="side-menu">
                            <li>
                                <a href="dashboard_admin.php?p=dashboard">
                                    <i class="fe-airplay"></i>
                                    <span> Dashboard </span>
                                </a>
                            </li>

                            <div class="dropdown-divider"></div>

                            <li>
                                <a href="dashboard_admin.php?p=user">
                                    <i class="fe-users"></i>
                                    <span> Users </span>
                                </a>
                            </li>

                            <div class="dropdown-divider"></div>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-file"></i>
                                    <span> All Data </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li><a href="dashboard_admin.php?p=jenis_usaha"><i class="fe-tag"></i> Jenis Usaha</a></li>

                                    <li><a href="dashboard_admin.php?p=data_pemohon"><i class="fe-tag"></i> Data Pemohon</a></li>
                                    
                                    <li><a href="dashboard_admin.php?p=permohonan_skiu"><i class="fe-tag"></i> Data Pemohonan SKIU</a></li>
                                </ul>
                            </li>

                            <div class="dropdown-divider"></div>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-folder"></i>
                                    <span> Laporan </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li><a href="dashboard_admin.php?p=lap_skiu"><i class="fe-tag"></i> Laporan SKIU</a></li>
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Start Content-->
                    <div class="container-fluid">
                    </div> <!-- end container-fluid -->
                </div> <!-- end content -->
                <?php
                 $pages_dir='admin';
                 if(!empty($_GET['p'])){
                  $pages=scandir($pages_dir,0);
                  unset($pages[0],$pages[1]);
                  $p=$_GET['p'];
                  if(in_array($p.'.php',$pages)){
                    include($pages_dir.'/'.$p.'.php');
                  }else{
                    echo'Halaman Tidak Ditemukan !!!';
                  }
                }else{
                  include($pages_dir.'/dashboard.php');
                }
                ?>
                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2023- <?php echo date('Y'); ?> &copy; APP SKIU by <a href="">hello 72</a>
                            </div>
            
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->
            </div>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->
        </div>
        <!-- END wrapper -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>
        <!-- Vendor js -->
        <script src="dist/assets/js/vendor.min.js"></script>
         <!-- Chart JS -->
         <script src="dist/assets/libs/chart-js/Chart.bundle.min.js"></script>
          <!-- Init js -->
        <script src="dist/assets/js/pages/dashboard.init.js"></script>
        <!-- App js -->
        <script src="dist/assets/js/app.min.js"></script>
        <!-- Required datatable js -->
        <script src="dist/assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="dist/assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

        <!-- Responsive examples -->
        <script src="dist/assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="dist/assets/libs/datatables/responsive.bootstrap4.min.js"></script>

        <!-- Datatables init -->
        <script src="dist/assets/js/pages/datatables.init.js"></script>
    </body>
</html>