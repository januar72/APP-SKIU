<?php include 'koneksi.php';

$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_skiu WHERE id_skiu='$id'");
header("location:dashboard_visitor.php?p=data_skiu&notif=sukses_hapus");
 ?>