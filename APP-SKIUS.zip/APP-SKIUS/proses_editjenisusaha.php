<?php 
include 'koneksi.php';

$id =$_GET['id'];

$nama_usaha =$_POST['nama_usaha'];

$edit_data =mysqli_query($konek, "UPDATE `jenis_usaha` SET nama_usaha='$nama_usaha' WHERE id_jenis='$id'");
header("location:dashboard_admin.php?p=jenis_usaha&notif=sukses_edit");

 ?>