<?php 
include 'koneksi.php';

$id =$_GET['id'];
$nama =$_POST['nama'];
$username =$_POST['username'];
$jabatan =$_POST['jabatan'];
$status =$_POST['status'];

$edit_data =mysqli_query($konek, "UPDATE `tb_user` SET nama='$nama', username='$username', jabatan='$jabatan', status='$status' WHERE id_user='$id'");
header("location:dashboard_admin.php?p=user&notif=sukses_edit");
 ?>