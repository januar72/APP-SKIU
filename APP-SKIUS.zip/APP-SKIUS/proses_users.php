<?php 
include 'koneksi.php';

$nama 		=$_POST['nama'];
$username 	=$_POST['username'];
$password 	=$_POST['password'];
$jabatan 	=$_POST['jabatan'];
$status 	=$_POST['status'];

$tampil =mysqli_query($konek, "SELECT * FROM tb_user WHERE username='$username'");
$tam =mysqli_num_rows($tampil);
$tam_tam =mysqli_fetch_array($tampil);
if ($tam > 0) {
	header("location:dashboard_admin.php?p=user&notif=gagal");
}elseif ($tam == 0) {
	$simpan =mysqli_query($konek, "INSERT INTO `tb_user` (`id_user`,`nama`,`username`,`password`,`jabatan`,`status`) VALUES (null, '$nama','$username','$password','$jabatan', 'Aktif')");
	header("location:dashboard_admin.php?p=user&notif=sukses");
}


 ?>