<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$tgl_input =$_POST['tgl_input'];
$tempat_lahir =$_POST['tempat_lahir'];
$tgl_lahir =$_POST['tgl_lahir'];
$jk =$_POST['jk'];
$agama =$_POST['agama'];
$pekerjaan =$_POST['pekerjaan'];
$status =$_POST['status'];
$nik  =$_POST['nik'];
$alamat =$_POST['alamat'];
$nama_usaha =$_POST['nama_usaha'];

$tampil_a=mysqli_query($konek, "SELECT * FROM tb_skiu WHERE nama='$nama' AND nik='$nik'");
$tam_a =mysqli_num_rows($tampil_a);
$cam_a =mysqli_fetch_array($tampil_a);
if ($tam_a > 0) {
	header("location:dashboard_visitor.php?p=data_skiu&notif=gagal");
}elseif ($tam_a == 0) {
$simpan =mysqli_query($konek, "INSERT INTO `tb_skiu` (`id_skiu`,`nama`,`tgl_input`,`tempat_lahir`,`tgl_lahir`,`jk`,`agama`,`pekerjaan`,`status`,`nik`,`alamat`,`nama_usaha`) VALUES (null, '$nama','$tgl_input','$tempat_lahir','$tgl_lahir','$jk','$agama','$pekerjaan','$status','$nik','$alamat','$nama_usaha')");
header("location:dashboard_visitor.php?p=data_skiu&notif=sukses");
}
 ?>