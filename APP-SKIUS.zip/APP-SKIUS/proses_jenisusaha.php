<?php 
include 'koneksi.php';

$nama_usaha =$_POST['nama_usaha'];

$simpan =mysqli_query($konek, "INSERT INTO `jenis_usaha` (`id_jenis`,`nama_usaha`) VALUES (null, '$nama_usaha')");
header("location:dashboard_admin.php?p=jenis_usaha&notif=sukses");
 ?>