/*
Template Name: Abstack - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
File: Tablesaw tables init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
