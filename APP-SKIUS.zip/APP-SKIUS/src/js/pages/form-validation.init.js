/*
Template Name: Abstack - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
File: Form validation init js
*/

$(document).ready(function() {
    $('.parsley-examples').parsley();
});


