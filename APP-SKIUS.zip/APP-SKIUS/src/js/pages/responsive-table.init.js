/*
Template Name: Abstack - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
File: Responsive table init js
*/

$(function() {
    $('.table-responsive').responsiveTable({
        addDisplayAllBtn: 'btn btn-secondary'
    });
});
