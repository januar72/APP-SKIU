<div class="row">
	<div class="col-md-4 mt-2">
		<div class="card card-body">
			<div class="card-title">
				<h5>Input Jenis Usaha</h5>
			</div>
			<form method="post" action="proses_jenisusaha.php">
				<div class="form-group">
					<label>Nama Usaha</label>
					<input type="text" name="nama_usaha" class="form-control" required>
				</div>
				<div class="box-footer">
					<input type="submit" name="simpan" class="btn btn-gradient">
				</div>
			</form>
		</div>
	</div>
	<div class="col-md-8 mt-2">
		<div class="card card-body">
			<div class="card-title">
				<h5>Tabel Jenis Usaha</h5>
			</div>
			<?php if (isset($_GET['notif'])) {
				if ($_GET['notif'] =='sukses') {
					echo "
					<div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
					<a href='dashboard_admin.php?p=jenis_usaha' class='close' style='text-decoration: none;'>&times;</a>
					<h4 style='font-size: 12px;'><i class='fe-check'></i>Sukses!</h4>
					Proses Data Berhasil Di Simpan....!
					</div>
					";
				}elseif ($_GET['notif'] == 'sukses_edit') {
					echo "
					<div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
					<a href='dashboard_admin.php?p=jenis_usaha' class='close' style='text-decoration: none;'>&times;</a>
					<h4 style='font-size: 12px;'><i class='fe-x'></i>Sukses!</h4>
					Proses Data Berhasil Di Ubah....!
					</div>
					";
				}
			}else{
				echo "";
			} ?>
			<table id="datatable" class="table table-bordered dt-responsive nowrap" width="100%">
				<thead>
					<tr>
						<th>No</th>
						<th>Nama Usaha</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php include 'koneksi.php';
					$no=1;
					$tam=mysqli_query($konek, "SELECT * FROM jenis_usaha");
					while ($data=mysqli_fetch_array($tam)) {?>
						<tr>
							<td><?php echo $no++; ?></td>
							<td><?php echo $data['nama_usaha']; ?></td>
							<td>
								<a href="dashboard_admin.php?p=edit_usaha&id=<?php echo $data['id_jenis']; ?>"><i class="fe-edit"></i></a>
							</td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>