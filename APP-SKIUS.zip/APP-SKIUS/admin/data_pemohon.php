<div class="row">
	<div class="col-md-4 mt-2">
		<div class="card card-body">
			<div class="card-title">
				<h5>Input Pemohon</h5>
			</div>
			<div class="dropdown-divider"></div>
			<form method="post" action="proses_pemohon.php">
				<div class="form-group">
					<label>Nama</label>
					<input type="text" name="nama" class="form-control" required>
				</div>
				<div class="form-group">
					<label>Rt/Rw</label>
					<input type="text" name="rt" class="form-control" required>
				</div>
				<div class="form-group">
					<label>Alamat</label>
					<input type="text" name="alamat" class="form-control" required>
				</div>
				<div class="form-group">
					<label>No Hp</label>
					<input type="number" name="no_hp" class="form-control" required>
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="email" name="email" class="form-control" required>
				</div>
				<div class="box-footer">
					<input type="submit" name="simpan" class="btn btn-gradient">
				</div>
			</form>
		</div>
	</div>
	<div class="col-md-8 mt-2">
		<div class="card card-body" style="overflow: auto;">
			<div class="card-title">
				<h5>Tabel Pemohon</h5>
			</div>
			<?php if (isset($_GET['notif'])) {
				if ($_GET['notif']=='sukses') {
					echo "
            <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
            <a href='dashboard_admin.php?p=data_pemohon' class='close' style='text-decoration:none'>&times;</a>
            <h4 style='font-size:12px;'><i class='fe-check'></i> Sukses!</h4>
              Proses simpan data berhasil...
            </div>";
				}elseif ($_GET['notif']=='sukses_hapus') {
					echo "
            <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
            <a href='dashboard_admin.php?p=data_pemohon' class='close' style='text-decoration:none'>&times;</a>
            <h4 style='font-size:12px;'><i class='fe-x'></i> Sukses!</h4>
              Proses hapus data berhasil...
            </div>";
				}elseif ($_GET['notif'] =='sukses_edit') {
					echo "
						<div class='alert alert-warning alert-dismissible' style='text-align: justify; font-size:10px;'>
						 <a href='dashboard_admin.php?p=data_pemohon' class='close'
						 style='text-decoration:no_hp'>&times;</a>
						 <h4 style='font-size:12px;'><i class='fe-check'></i> Sukses!</h4>
						 Proses Edit Berhasil silakan cek kembali data anda..!
						</div>
					";
				}
			}else{
				echo "";
			} ?>
			<table id="datatable" class="table table-bordered dt-responsive nowrap" width="100%">
				<thead>
					<tr>
						<th>No</th>
						<th>Nama</th>
						<th>Rt/Rw</th>
						<th>Alamat</th>
						<th>No Hp</th>
						<th>Email</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php include 'koneksi.php';
					$no=1;
					$tam=mysqli_query($konek, "SELECT * FROM tb_pemohon");
					while ($data=mysqli_fetch_array($tam)) {?>
						<tr>
							<td><?php echo $no++ ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['rt']; ?></td>
							<td><?php echo $data['alamat']; ?></td>
							<td><?php echo $data['no_hp']; ?></td>
							<td><?php echo $data['email']; ?></td>
							<td>
								<a href="" data-toggle="modal" data-target=".edit-modal<?php echo $data['id_pemohon']; ?>"><i class="fe-edit"></i></a>

								<a href="hapus_pemohon.php?id=<?php echo $data['id_pemohon']; ?>" class=""><i class="fe-trash-2"></i></a>
							</td>
							<!--  Modal content for the above example -->
							<div class="modal fade edit-modal<?php echo $data['id_pemohon']; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
							    <div class="modal-dialog modal-lg">
							        <div class="modal-content">
							            <div class="modal-header">
							                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
							                <h4 class="modal-title" id="myLargeModalLabel">Edit Pemohon</h4>
							            </div>
							            <div class="modal-body">
							                <form method="post" action="proses_editpemohon.php?id=<?php echo $data['id_pemohon']; ?>">
							                    <div class="row">
							                    <input type="hidden" name="id_pemohon" value="<?php echo $data['id_pemohon']; ?>">
							                    <div class="col-md-6">
							                    	<div class="form-group">
							                    		<label>Nama</label>
							                    		<input type="text" name="nama" value="<?php echo $data['nama']; ?>" class="form-control">
							                    	</div>
							                    </div>
							                    <div class="col-md-6">
							                    	<div class="form-group">
							                    		<label>RT/RW</label>
							                    		<input type="text" name="rt" value="<?php echo $data['rt']; ?>" class="form-control" required>
							                    	</div>
							                    </div>
							                    <div class="col-md-6">
							                    	<div class="form-group">
							                    		<label>Alamat</label>
							                    		<input type="text" name="alamat" value="<?php echo $data['alamat']; ?>" class="form-control" required>
							                    	</div>
							                    </div>
							                    <div class="col-md-6">
							                    	<div class="form-group">
							                    		<label>No Hp</label>
							                    		<input type="text" name="no_hp" value="<?php echo $data['no_hp']; ?>" class="form-control" required>
							                    	</div>
							                    </div>
							                    <div class="col-md-3">
							                    	<div class="form-group">
							                    		<label>Email</label>
							                    		<input type="text" name="email" value="<?php echo $data['email']; ?>" class="form-control">
							                    	</div>
							                    </div>
							                    </div>
							                    <div class="box-footer">
							                        <input type="submit" name="simpan" class="btn btn-gradient">
							                    </div>
							                </form>
							            </div>
							        </div><!-- /.modal-content -->
							    </div><!-- /.modal-dialog -->
							</div><!-- /.modal -->
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

