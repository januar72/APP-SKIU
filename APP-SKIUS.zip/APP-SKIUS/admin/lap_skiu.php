<section class="content-header">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"> <a href=""> Dashboard</a></li>
                        <li class="breadcrumb-item"> <a href=""> Admin</a></li>
                        <li class="breadcrumb-item active"> Data SKIU</li>
                    </ol>
                </div>
                <h4 class="page-title">Laporan data SKIU</h4>
            </div>
        </div>
    </div>
</section>
<section class="content">
<div class="row">
    <div class="col-12">
        <div class="card-box ">
              <div class="card-header d-flex p-0">
                
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab"><i class="fa fa-print"></i> Laporan Skiu Per Minggu</a></li>
                  
                  <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab"><i class="fa fa-print"></i> Laporan Skiu Per Bulan</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="box-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                     <form role="form" method="post" target="_blank" action="./lap_skiu_a.php">
                      <div class="row">
                        <div class="col-lg-5">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tanggal Awal</label>
                            <input type="date" name="ta" class="form-control" required>
                          </div>
                        </div>
                        <div class="col-lg-6">
                         <div class="form-group">
                            <label for="exampleInputEmail1">Tanggal Akhir</label>
                            <input type="date" name="tak" class="form-control" required>
                          </div>
                        </div>
                       
                        <div class="col-lg-1">
                            <button type="submit" class="btn btn-primary btn-sm"  style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                     <form role="form" method="post" target="_blank" action="./lap_skiu.php">
                      <div class="row">
                        <div class="col-lg-5">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-1">
                          <button type="submit" class="btn btn-primary btn-sm"  style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                  </div>
                  <!-- /.tab-pane -->
                  
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>

        <div class="card-box">
              <div class="box-header with-border" style="overflow: auto;">
                <table style="width: 100%;">
                </table>
               
              </div>
              <div class="box-body" style="overflow: auto;">
                 <table id="example1" class="table table-bordered">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tempat Lahir</th>
                    <th>Tanggal Lahir</th>
                    <th>Jenis Kelamin</th>
                    <th>Agama</th>
                    <th>Pekerjaan</th>
                    <th>Status</th>
                    <th>Nik</th>
                    <th>Alamat</th>
                    <th>Nama Usaha</th>
                    <th style="font-size: 8px; font-style: italic;">Cetak SKIU</th>
                  </tr>
                  </thead>
                  <tbody>
                 <?php include 'koneksi.php';
                 $no=1;
                 $tam_a =mysqli_query($konek, "SELECT * FROM tb_skiu");
                 while ($data_a=mysqli_fetch_array($tam_a)) {?>
                  <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $data_a['nama']; ?></td>
                    <td><?php echo $data_a['tempat_lahir']; ?></td>
                    <td><?php echo $data_a['tgl_lahir']; ?></td>
                    <td><?php echo $data_a['jk']; ?></td>
                    <td><?php echo $data_a['agama']; ?></td>
                    <td><?php echo $data_a['pekerjaan']; ?></td>
                    <td><?php echo $data_a['status']; ?></td>
                    <td><?php echo $data_a['nik']; ?></td>
                    <td><?php echo $data_a['alamat']; ?></td>
                    <td><?php echo $data_a['nama_usaha']; ?></td>
                    <td>
                        <a href="dashboard_admin.php?p=cetak_skiu&id=<?php echo $data_a['id_skiu']; ?>" style="color: green;"><i class="fe-download-cloud"></i></a>
                    </td>
                  </tr>
                <?php } ?>
                </tbody>
                </table>
              </div>
            </div>
    </div>
</div>
</section>
