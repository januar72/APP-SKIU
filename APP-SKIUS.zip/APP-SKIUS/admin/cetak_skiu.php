<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>APP SKIU</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="dist/assets/libs/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="dist/assets/libs/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="dist/assets/libs/css/app.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body>

    <!-- Begin page -->
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card-box">
                    <div class="clearfix">
                        <div class="float-left">
                            <img src="assets/images/logo-dark.png" alt="" height="18">
                        </div>
                        <div class="float-right">
                            <h4 class="m-0 d-print-none">SKIU</h4>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-6">
                            <div class="float-left mt-3">
                                <p><b>Hello, Sahabat ...</b></p>
                                <p class="text-muted"> Simpan Surat Ini, sebagai tanda Surat Keterangan Ijin Usaha, bagi surat yang sudah hialng silakan login, dan download kembali surat anda pada aplikasi SKIU. </p>
                            </div>

                        </div><!-- end col -->
                        <div class="col-4 offset-2">
                            <div class="mt-3 float-right">
                                <p class="mb-2"><strong> Date: </strong> <?php echo date('y-d-m'); ?></p>
                                <p class="mb-2"><strong>Status: </strong> <span class="badge badge-success">Aktif</span></p>
                            </div>
                        </div><!-- end col -->
                    </div>
                    <!-- end row -->

                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table mt-4">
                                    <thead>
                                    <tr><th>#</th>
                                        <th>Nama</th>
                                        <th>Tempat Lahir</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Agama</th>
                                        <th>Pekerjaan</th>
                                        <th>Status</th>
                                        <th>Nik</th>
                                        <th>Alamat</th>
                                        <th>Nama Usaha</th>
                                    </tr></thead>
                                    <tbody>
                                     <?php include 'koneksi.php';
                                     $id =$_GET['id'];
                                     $no =1;
                                     $tam_a=mysqli_query($konek,"SELECT * FROM tb_skiu WHERE id_skiu='$id'");
                                     while ($data=mysqli_fetch_array($tam_a)) {?>
                                      <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo $data['nama']; ?></td>
                                        <td><?php echo $data['tempat_lahir']; ?></td>
                                        <td><?php echo $data['tgl_lahir']; ?></td>
                                        <td><?php echo $data['jk']; ?></td>
                                        <td><?php echo $data['agama']; ?></td>
                                        <td><?php echo $data['pekerjaan']; ?></td>
                                        <td><?php echo $data['status']; ?></td>
                                        <td><?php echo $data['nik']; ?></td>
                                        <td><?php echo $data['alamat']; ?></td>
                                        <td><?php echo $data['nama_usaha']; ?></td>
                                      </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="clearfix pt-4">
                                <h5 class="text-muted">Mengetahui....</h5>

                                <br><br><br><br><br>
                                <small>
                                    <h5 class="text-muted">.......................</h5>
                                </small>
                            </div>

                        </div>
                        <div class="col-6">
                            <div class="float-right">
                              
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="hidden-print mt-4 mb-4">
                        <div class="text-right d-print-none">
                            <a href="javascript:window.print()" class="btn btn-primary waves-effect waves-light"><i class="fa fa-print mr-1"></i> Print</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- end row --> 
    </div>
    <!-- END wrapper -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>

    <script>window.print();</script>
        
    </body>
</html>