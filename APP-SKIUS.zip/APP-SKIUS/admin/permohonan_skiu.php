<div class="row">
	<div class="col-md-12 mt-2">
		<div class="card card-body">
			<div class="card-title">
				<h3>Data Permohonan SKIU</h3>
			
			<button type="button" class="btn btn-gradient waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg"><i class="fe-plus">Add Permohonan SKIU</i></button>
			</div>
			<?php if (isset($_GET['notif'])) {
				if ($_GET['notif'] == 'sukses') {
					echo "
					<div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=permohonan_skiu' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='fe-check'></i> Sukses!</h4>
                        Proses simpan data berhasil..
                      </div>
					";
				}elseif ($_GET['notif'] =='sukses_hapus') {
					echo "
					<div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=permohonan_skiu' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='fe-x'></i> Sukses!</h4>
                        Proses hapus data berhasil..
                      </div>
					";
				}elseif ($_GET['notif'] == 'sukses_edit') {
					echo "
					<div class='alert alert-warning alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=permohonan_skiu' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='fe-check'></i> Sukses!</h4>
                        Proses edit data berhasil..
                      </div>
					";
				}
			}else{
				echo "";
			} ?>
			<table id="datatable" class="table table-bordered dt-responsive nowrap" width="100%">
				<thead>
					<tr>
						<th>No</th>
						<th>Nama Pemohon</th>
						<th>Jenis Usaha</th>
						<th>Syrat Pemohon</th>
						<th>Skala Usaha</th>
						<th>Lokasi Usaha</th>
                        <th style="font-size: 8px;">Lihat Data</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php include 'koneksi.php';
					$no=1;
					$cam_a=mysqli_query($konek, "SELECT * FROM permohonan_skiu");
					while ($data_cam=mysqli_fetch_array($cam_a)) {?>
						<tr>
							<td><?php echo $no++; ?></td>
							<td><?php echo $data_cam['nama']; ?></td>
							<td><?php echo $data_cam['jenis_usaha']; ?></td>
							<td><?php echo $data_cam['syrat_pemohon']; ?></td>
							<td><?php echo $data_cam['skala_usaha']; ?></td>
							<td><?php echo $data_cam['lok_usaha']; ?></td>
							<td>
								<a href="" data-toggle="modal" data-target=".edit-modal<?php echo $data_cam['id_perskiu']; ?>"><i class="fe-edit"></i></a>

								<a href="hapus_perskiu.php?id=<?php echo $data_cam['id_perskiu']; ?>" class=""><i class="fe-trash-2"></i></a>
							</td>
                            <!--  Modal content for the above example -->
                            <div class="modal fade edit-modal<?php echo $data_cam['id_perskiu']; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myLargeModalLabel">Edit Permohonan SKIU</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="proses_editperskiu.php?id=<?php echo $data_cam['id_perskiu']; ?>">
                                                <div class="row">
                                                <input type="hidden" name="id_perskiu" value="<?php echo $data_cam['id_perskiu']; ?>">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Nama</label>
                                                        <input type="text" name="nama" value="<?php echo $data_cam['nama']; ?>" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Jenis Usaha</label>
                                                        <input type="text" name="jenis_usaha" value="<?php echo $data_cam['jenis_usaha']; ?>" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Syrat Pemohon</label>
                                                        <input type="text" name="syrat_pemohon" value="<?php echo $data_cam['syrat_pemohon']; ?>" class="form-control" required>
                                                    </div>
                                                </div>
                                                    
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Skala Usaha</label>
                                                        <input type="text" name="skala_usaha" value="<?php echo $data_cam['skala_usaha']; ?>" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Lokasi Usaha</label>
                                                        <input type="text" name="lok_usaha" value="<?php echo $data_cam['lok_usaha']; ?>" class="form-control" required>
                                                    </div>
                                                </div>

                                                </div>
                                                <div class="box-footer">
                                                    <input type="submit" name="simpan" class="btn btn-gradient">
                                                </div>
                                            </form>
                                        </div>
                                    </div><!-- /.modal-content -->
                                </div><!-- /.modal-dialog -->
                            </div><!-- /.modal -->
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<!--  Modal content for the above example -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myLargeModalLabel">Data Permohonan SKIU</h4>
            </div>
            <div class="modal-body">
                <form method="post" action="proses_perskiu.php">
                    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Nama Pemohon</label>
                            <select class="form-control" name="nama" required>
                            	<option>--pilih--</option>
                            	<?php include 'koneksi.php';
                            	$tam_a=mysqli_query($konek, "SELECT * FROM tb_pemohon");
                            	while ($data_a=mysqli_fetch_array($tam_a)) {?>
                            		<option value="<?php echo $data_a['nama']; ?>"><?php echo $data_a['nama']; ?></option>
                            	<?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Jenis Usaha</label>
                            <select name="nama_usaha" class="form-control">
                                <option>--Pilih Jensi--</option>
                                <?php include 'koneksi.php';
                                $tamp_c =mysqli_query($konek, "SELECT * FROM jenis_usaha");
                                while ($data=mysqli_fetch_array($tamp_c)) {?>
                                    <option value="<?php echo $data['nama_usaha']; ?>"><?php echo $data['nama_usaha']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Syrat Pemohon</label>
                            <input type="text" name="syrat_pemohon" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Skala Usaha</label>
                    		<input type="text" name="skala_usaha" class="form-control">
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Lokasi Usaha</label>
                    		<input type="text" name="lok_usaha" class="form-control" required>
                    	</div>
                    </div>
                    </div>
                    <div class="box-footer">
                        <input type="submit" name="simpan" class="btn btn-gradient">
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
