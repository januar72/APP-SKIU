<div class="row">
    <div class="col-md-12 mt-2">
        <div class="card card-body">
            <div class="card-title">
                <button type="button" class="btn btn-gradient waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg"><i class="fe-plus">Add Users</i></button>
            </div>
             <?php
                  if(isset($_GET['notif'])){
                    if($_GET['notif']=="gagal"){
                      echo "
                      <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=user' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-ban'></i> Gagal!</h4>
                        Proses simpan data gagal, Nama dan Username yang anda masukkan sudah digunakan oleh pengguna lain. Silahkan masukkan Username yang berbeda
                      </div>";
                    }elseif ($_GET['notif']=="sukses") {
                      echo "
                      <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=user' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='fe-check'></i> Sukses!</h4>
                        Proses simpan data berhasil, Silahkan Login Sekarang..
                      </div>";
                  }elseif ($_GET['notif'] =="sukses_edit") {
                     echo "
                      <div class='alert alert-warning alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=user' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='fe-check'></i> Sukses!</h4>
                        Proses Update data berhasil, Silahkan Login Sekarang..
                      </div>";
                  }
                  }else{
                    echo "";
                  }
                ?>
            <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; width: 100%; border-spacing: 0;">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include 'koneksi.php';
                    $no=1;
                    $tamp=mysqli_query($konek, "SELECT * FROM tb_user");
                    while ($data=mysqli_fetch_array($tamp)) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $data['nama']; ?></td>
                            <td><?php echo $data['username']; ?></td>
                            <td><?php echo $data['jabatan']; ?></td>
                            <td><?php echo $data['status']; ?></td>
                            <td>
                                <a href="" data-toggle="modal" data-target=".edit-modal<?php echo $data['id_user']; ?>"><i class="fe-edit"></i></a>

                                <a href="proses_hpsusers.php?id=<?php echo $data['id_user']; ?>" class=""><i class="fe-trash-2"></i></a>
                            </td>
                            <!--  Modal content for the above example -->
                            <div class="modal fade edit-modal<?php echo $data['id_user']; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title" id="myLargeModalLabel">Edit Users</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="post" action="proses_edituser.php?id=<?php echo $data['id_user']; ?>">
                                                <div class="row">
                                                <input type="hidden" name="id_user" value="<?php echo $data['id_user']; ?>">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Nama</label>
                                                        <input type="text" name="nama" value="<?php echo $data['nama']; ?>" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Username</label>
                                                        <input type="text" name="username" value="<?php echo $data['username']; ?>" class="form-control" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Jabatan</label>
                                                        <select name="jabatan" value="<?php echo $data['jabatan']; ?>" class="form-control">
                                                            <option value="Admin">Admin</option>
                                                            <option value="Visitor">Visitor</option>
                                                            <option value="Lurah">Lurah</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Status</label>
                                                        <select name="status" value="<?php echo $data['status']; ?>" class="form-control">
                                                            <option value="Aktif">Aktif</option>
                                                            <option value="Non Aktif">Non Aktif</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="box-footer">
                                                    <input type="submit" name="simpan" class="btn btn-gradient">
                                                </div>
                                            </form>
                                        </div>
                                    </div><!-- /.modal-content -->
                                </div><!-- /.modal-dialog -->
                            </div><!-- /.modal -->
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

 <!--  Modal content for the above example -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myLargeModalLabel">Data User</h4>
            </div>
            <div class="modal-body">
                <form method="post" action="proses_users.php">
                    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="nama" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Jabatan</label>
                            <select name="jabatan" class="form-control">
                                <?php include 'koneksi.php';
                                $tam =mysqli_query($konek, "SELECT * FROM tb_user WHERE jabatan='Lurah' AND status ='Aktif'");
                                $data_tam=mysqli_num_rows($tam);
                                $data =mysqli_fetch_array($tam);
                                if ($data_tam > 0) {
                                     echo "
                                     <option value='Admin'>Admin</option>
                                     <option value='Lurah'>Lurah</option>
                                     <option value='Visitor'>Visitor</option>
                                     ";
                                 }elseif ($data_tam == 0) {
                                     echo "
                                     <option value='Admin'>Admin</option>
                                     <option value='Lurah'>Lurah</option>
                                     <option value='Visitor'>Visitor</option>
                                     ";
                                 } ?>
                            </select>
                        </div>
                    </div>
                    </div>
                    <div class="box-footer">
                        <input type="submit" name="simpan" class="btn btn-gradient">
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

