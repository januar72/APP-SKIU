<div class="row">
	<div class="col-md-12 mt-2">
		<div class="card card-body">
			<div class="card-title">
				<h5>Edit Form Jenis Usaha</h5>
			</div>
			<?php include 'koneksi.php';
			$id =$_GET['id'];
			$tam =mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM jenis_usaha WHERE id_jenis='$id'")); ?>
			<form method="post" action="proses_editjenisusaha.php?id=<?php echo $tam['id_jenis']; ?>">
				<input type="hidden" name="id_jenis" value="<?php echo $tam['id_jenis']; ?>">
				<div class="col-md-12">
					<div class="form-group">
						<label>Nama Usaha</label>
						<input type="text" name="nama_usaha" value="<?php echo $tam['nama_usaha']; ?>" class="form-control">
					</div>
					<div class="box-footer">
						<input type="submit" name="simpan" class="btn btn-gradient">
					</div>
				</div>
			</form>
		</div>
	</div>
</div>