<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">APP SKIU</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
            <h4 class="page-title">Dashboard</h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
        <div class="col-md-6 col-xl-4">
            <div class="card-box tilebox-one">
                <i class="fe-user float-right"></i>
                <h5 class="text-muted text-uppercase mb-3 mt-0">Users</h5>
                <?php include 'koneksi.php';
                $tam_a =mysqli_query($konek, "SELECT count(nama) AS total FROM tb_user");
                while ($data=mysqli_fetch_array($tam_a)) {?>
                <h3 class="mb-3" data-plugin="counterup"><?php echo $data['total']; ?></h3>
                <?php } ?>
                <span class="badge badge-primary"></span> <span class="text-muted ml-2 vertical-middle">Users Pengguna Sistem</span>
            </div>
        </div>

        <div class="col-md-6 col-xl-4">
            <div class="card-box tilebox-one">
                <i class="fe-users float-right"></i>
                <h5 class="text-muted text-uppercase mb-3 mt-0">Pengunjung</h5>
                <?php include 'koneksi.php';
                $tam=mysqli_query($konek, "SELECT count(nama) AS total FROM tb_pemohon");
                while ($data_a=mysqli_fetch_array($tam)) {?>
                <h3 class="mb-3"><span data-plugin="counterup"><?php echo $data_a['total']; ?></span></h3>
                <?php } ?>
                <span class="badge badge-primary"></span> <span class="text-muted ml-2 vertical-middle">Jumlah Pengunjung</span>
            </div>
        </div>

        <div class="col-md-6 col-xl-4">
            <div class="card-box tilebox-one">
                <i class="fe-file float-right"></i>
                <h5 class="text-muted text-uppercase mb-3 mt-0">SKIU</h5>
                <?php include 'koneksi.php';
                $tamp=mysqli_query($konek, "SELECT count(nama) AS total FROM tb_skiu");
                while ($tamp_a=mysqli_fetch_array($tamp)) {?>
                <h3 class="mb-3"><span data-plugin="counterup"><?php echo $tamp_a['total']; ?></span></h3>
                <?php } ?>
                <span class="badge badge-primary"></span> <span class="text-muted ml-2 vertical-middle">Laporan Skiu Terealisasi</span>
            </div>
        </div>
    </div>