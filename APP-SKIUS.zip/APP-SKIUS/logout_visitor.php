<?php 
session_start();
unset($_SESSION['masuktwo']);
 echo "<script>document.location.href='index.php'</script>\n";
 ?>