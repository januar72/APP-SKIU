<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM permohonan_skiu WHERE id_perskiu='$id'");
header("location:dashboard_admin.php?p=permohonan_skiu&notif=sukses_hapus");
 ?>