
<div class="row">
	<div class="col-md-12 mt-2">
		<div class="card card-body">
			<div class="card-title">
				<h5>Input data SKIU</h5>
				<button type="button" class="btn btn-gradient waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg"><i class="fe-plus">Add Permohonan SKIU</i></button>
			</div>
			<?php if (isset($_GET['notif'])) {
				if ($_GET['notif'] == 'sukses') {
					echo "
					<div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
					<a href='dashboard_visitor.php?p=data_skiu' class='close' style='text-decoration: none;'>&times;</a>
					<h4 style='font-size: 12px;'><i class='fe-check'></i>Sukses!</h4>
					Data Anda Berhasil Di Simpan....!
					</div>
					";
				}elseif ($_GET['notif'] == 'sukses_hapus') {
                    echo "
                    <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                    <a href='dashboard_visitor.php?p=data_skiu' class='close' style='text-decoration: none;'>&times;</a>
                    <h4 style='font-size: 12px;'><i class='fe-x'></i>Sukses!</h4>
                    Proses Hapus Data Berhasil....!
                    </div>
                    ";
                }elseif ($_GET['notif'] =='gagal') {
                     echo"
                    <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                    <a href='dashboard_visitor.php?p=data_skiu' class='close' style='text-decoration: none;'>&times;</a>
                    <h4 style='font-size: 12px;'><i class='fe-x'></i>Sukses!</h4>
                    Opss....! Data yang anda input sudah terdaftar, mohon cek kembali, jika ada kesalahan silakan hapus dan input kembali....!
                    </div>
                    ";
                }
			}else{
				echo "
                <div class='alert alert-warning alert-dismissible' style='text-align: justify; font-size: 10px;'>
                <a href='dashboard_visitor.php?p=data_skiu' class='close'
                style='text-decoration: none;'>&times;</a>
                <h4 style='font-size:12px;'><i class='fe-x'></i>    Perhatikan!</h4>
                Pastikan Input Data Anda sesuai dengan dokummen, jangan sesekali edit ataupun menghapus data orang lain, jika terjadi kesalahan input hapus berdasrkan nama dan silakan input kembali!
                </div>
                ";
			} ?>
			<table id="datatable" class="table table-bordered dt-responsive nowrap" width="100%">
				<thead>
					<tr>
						<th>No</th>
                        <th>Tanggal Input</th>
                        <th>Nama</th>
                        <th>Tempat Lahir</th>
                        <th>Tgl Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Agama</th>
                        <th>Pekerjaan</th>
                        <th>Status</th>
                        <th>Nik</th>
                        <th>Alamat</th>
                        <th>Nama Usaha</th>
                        <th>Aksi</th>
					</tr>
				</thead>
                <tbody>
                    <?php
                     include 'koneksi.php';
                     $no=1;
                    $tam_d =mysqli_query($konek, "SELECT * FROM tb_skiu");
                    while ($data_d =mysqli_fetch_array($tam_d)) {?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $data_d['tgl_input']; ?></td>
                            <td><?php echo $data_d['nama']; ?></td>
                            <td><?php echo $data_d['tempat_lahir']; ?></td>
                            <td><?php echo $data_d['tgl_lahir']; ?></td>
                            <td><?php echo $data_d['jk']; ?></td>
                            <td><?php echo $data_d['agama']; ?></td>
                            <td><?php echo $data_d['pekerjaan']; ?></td>
                            <td><?php echo $data_d['status']; ?></td>
                            <td><?php echo $data_d['nik']; ?></td>
                            <td><?php echo $data_d['alamat']; ?></td>
                            <td><?php echo $data_d['nama_usaha']; ?></td>
                            <td>
                                <a href="hapus_skiu.php?id=<?php echo $data_d['id_skiu']; ?>"><i class="fe-trash-2"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
			</table>
		</div>
	</div>
</div>
<!--  Modal content for the above example -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myLargeModalLabel">Data Permohonan SKIU</h4>
            </div>
            <div class="modal-body">
                <form method="post" action="proses_skiu.php">
                    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Nama Pemohon</label>
                            <select class="form-control" name="nama" required>
                            	<option>--pilih--</option>
                            	<?php include 'koneksi.php';
                            	$tam_a=mysqli_query($konek, "SELECT * FROM tb_pemohon");
                            	while ($data_a=mysqli_fetch_array($tam_a)) {?>
                            		<option value="<?php echo $data_a['nama']; ?>"><?php echo $data_a['nama']; ?></option>
                            	<?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Tanggal Input (<span style="font-size:9px; font-style: italic;">Pastikan tgl input hari ini!</span>)</label>
                            <input type="date" name="tgl_input" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Tanggal Lahir</label>
                            <input type="date" name="tgl_lahir" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Jenis Kelamin</label>
                    		<select name="jk" class="form-control">
                    			<option value="Laki Laki">Laki Laki</option>
                    			<option value="Perempuan">Perempuan</option>
                    		</select>
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Agama</label>
                    		<input type="text" name="agama" class="form-control" required>
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Pekerjaan</label>
                    		<input type="text" name="pekerjaan" class="form-control" required>
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Status</label>
                    		<input type="text" name="status" class="form-control" required>
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Nik</label>
                    		<input type="text" name="nik" class="form-control" required>
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Alamat</label>
                    		<input type="text" name="alamat" class="form-control" required>
                    	</div>
                    </div>
                    <div class="col-md-6">
                    	<div class="form-group">
                    		<label>Nama Usaha</label>
                    		<input type="text" name="nama_usaha" class="form-control" required>
                    	</div>
                    </div>
                    </div>
                    <div class="box-footer">
                        <input type="submit" name="simpan" class="btn btn-gradient">
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
