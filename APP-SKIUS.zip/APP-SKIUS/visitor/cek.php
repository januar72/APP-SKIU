<?php 
include 'koneksi.php';

$id =$_GET['id'];

$tamp =mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_user WHERE id_user='$id'"));
echo $tamp['nama'];

 ?>