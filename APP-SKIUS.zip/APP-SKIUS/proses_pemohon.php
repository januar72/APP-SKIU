<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$nama =$_POST['nama'];
	$rt =$_POST['rt'];
	$alamat =$_POST['alamat'];
	$no_hp =$_POST['no_hp'];
	$email =$_POST['email'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_pemohon` (`id_pemohon`,`nama`,`rt`,`alamat`,`no_hp`,`email`) VALUES (null, '$nama','$rt','$alamat','$no_hp','$email')");
header("location:dashboard_admin.php?p=data_pemohon&notif=sukses");
}
 ?>