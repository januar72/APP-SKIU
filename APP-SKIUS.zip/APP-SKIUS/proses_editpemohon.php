<?php 
include 'koneksi.php';

$id =$_GET['id'];
$nama =$_POST['nama'];
$rt =$_POST['rt'];
$alamat =$_POST['alamat'];
$no_hp =$_POST['no_hp'];
$email =$_POST['email'];

$edit_data=mysqli_query($konek, "UPDATE `tb_pemohon` SET nama='$nama', rt='$rt', alamat='$alamat', no_hp='$no_hp', email='$email' WHERE id_pemohon='$id'");
header("location:dashboard_admin.php?p=data_pemohon&notif=sukses_edit");
 ?>