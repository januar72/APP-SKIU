<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$jenis_usaha =$_POST['jenis_usaha'];
$syrat_pemohon =$_POST['syrat_pemohon'];
$skala_usaha =$_POST['skala_usaha'];
$lok_usaha =$_POST['lok_usaha'];

$simpan =mysqli_query($konek, "INSERT INTO `permohonan_skiu` (`id_perskiu`,`nama`,`jenis_usaha`,`syrat_pemohon`,`skala_usaha`,`lok_usaha`) VALUES (null,'$nama','$jenis_usaha','$syrat_pemohon','$skala_usaha','$lok_usaha')");
header("location:dashboard_admin.php?p=permohonan_skiu&notif=sukses");

 ?>